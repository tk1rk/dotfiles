-- ################# Basic settings dependent on plugins ################ --

-- ================= Visualization ================= --

vim.o.termguicolors = true
vim.o.background = 'dark'
vim.cmd('colorscheme material_dracula')
