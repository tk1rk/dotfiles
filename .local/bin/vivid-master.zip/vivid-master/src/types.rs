pub type FileType = String;
pub type Category = Vec<String>;
pub type CategoryRef<'a> = &'a [String];
